import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { GameLayout } from '@/components/game-layout'
import { GameRunner } from '@/components/games/game-runner'
import { GAMES, getGame } from '@/lib/games'

export function generateStaticParams() {
  return GAMES.map((g) => ({ slug: g.slug }))
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>
}): Promise<Metadata> {
  const { slug } = await params
  const game = getGame(slug)
  if (!game) return { title: 'Game not found' }
  return {
    title: game.metaTitle,
    description: game.metaDescription,
    openGraph: {
      title: game.metaTitle,
      description: game.metaDescription,
    },
  }
}

export default async function GamePage({
  params,
}: {
  params: Promise<{ slug: string }>
}) {
  const { slug } = await params
  const game = getGame(slug)
  if (!game) notFound()

  return (
    <GameLayout game={game}>
      <GameRunner slug={game.slug} />
    </GameLayout>
  )
}
