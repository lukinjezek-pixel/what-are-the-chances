import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Inter, Space_Grotesk } from 'next/font/google'
import './globals.css'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  weight: ['500', '600', '700'],
  variable: '--font-space-grotesk',
  display: 'swap',
})

export const metadata: Metadata = {
  metadataBase: new URL('https://what-are-the-chances.vercel.app'),
  title: {
    default: 'What Are the Chances? — Viral Mini-Games & Quick Tests',
    template: '%s — What Are the Chances?',
  },
  description:
    'Fast, addictive mini-games, reaction tests and brain teasers you can beat in under 2 minutes. Test yourself, then challenge your friends.',
  keywords: [
    'mini games',
    'reaction test',
    'quick quiz',
    'brain test',
    'speed click',
    'memory test',
    'challenge friends',
    'viral games',
  ],
  applicationName: 'What Are the Chances?',
  openGraph: {
    title: 'What Are the Chances? — Viral Mini-Games & Quick Tests',
    description:
      'Fast, addictive mini-games you can beat in under 2 minutes. Test yourself, then challenge your friends.',
    type: 'website',
    siteName: 'What Are the Chances?',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'What Are the Chances?',
    description:
      'Fast, addictive mini-games you can beat in under 2 minutes. Challenge your friends.',
  },
  generator: 'v0.app',
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#1a1424',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`dark ${inter.variable} ${spaceGrotesk.variable}`}>
      <body className="antialiased font-sans min-h-dvh">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
