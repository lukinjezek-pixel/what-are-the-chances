import { SiteHeader } from '@/components/site-header'
import { Hero } from '@/components/home/hero'
import { DailyChallenge } from '@/components/home/daily-challenge'
import { GameGrid } from '@/components/home/game-grid'
import { AdSlot } from '@/components/ad-slot'
import { GAMES, gamesInSection, getDailyGame } from '@/lib/games'

export default function HomePage() {
  const daily = getDailyGame()
  const trending = gamesInSection('trending')
  const quick = gamesInSection('quick')
  const versus = gamesInSection('versus')

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main className="flex-1">
        <Hero startHref={`/games/${daily.slug}`} />

        <div className="mx-auto w-full max-w-5xl space-y-14 px-4 pb-20">
          <DailyChallenge slug={daily.slug} />

          <GameGrid
            id="games"
            title="Trending now"
            caption="What everyone's playing today."
            games={trending}
          />

          <AdSlot label="Advertisement" />

          <GameGrid
            title="Quick tests"
            caption="One-minute brain and reflex checks."
            games={quick}
          />

          <GameGrid
            title="Beat your friends"
            caption="Save your score, then send the dare."
            games={versus}
          />

          <p className="text-center text-sm text-muted-foreground">
            {GAMES.length} games and counting — all free, all in your browser.
          </p>
        </div>
      </main>

      <footer className="border-t border-border/60 py-8 text-center text-xs text-muted-foreground">
        <p>
          What Are the Chances? — quick games, no gambling, no real-money risk. Just for fun.
        </p>
      </footer>
    </div>
  )
}
