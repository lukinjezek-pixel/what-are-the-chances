'use client'

import { useEffect, useState } from 'react'
import { Flame } from 'lucide-react'
import { getStreak } from '@/lib/storage'

export function StreakBadge() {
  const [streak, setStreak] = useState<number | null>(null)

  useEffect(() => {
    setStreak(getStreak())
    const onFocus = () => setStreak(getStreak())
    window.addEventListener('focus', onFocus)
    return () => window.removeEventListener('focus', onFocus)
  }, [])

  if (!streak) return null

  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full border border-gold/30 bg-gold/12 px-3 py-1.5 text-sm font-semibold text-gold"
      title={`You've played ${streak} day${streak === 1 ? '' : 's'} in a row`}
    >
      <Flame className="size-4" aria-hidden />
      {streak}
      <span className="sr-only">day streak</span>
    </span>
  )
}
