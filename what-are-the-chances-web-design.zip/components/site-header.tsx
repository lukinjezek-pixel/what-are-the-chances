import Link from 'next/link'
import { ArrowLeft, Sparkles } from 'lucide-react'
import { StreakBadge } from './streak-badge'
import { SoundToggle } from './sound-toggle'

export function SiteHeader({ back }: { back?: boolean }) {
  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 w-full max-w-5xl items-center justify-between gap-3 px-4">
        {back ? (
          <Link
            href="/"
            className="inline-flex items-center gap-2 rounded-full px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <ArrowLeft className="size-4" aria-hidden />
            All games
          </Link>
        ) : (
          <Link href="/" className="inline-flex items-center gap-2">
            <span className="grid size-8 place-items-center rounded-xl bg-primary text-primary-foreground">
              <Sparkles className="size-4" aria-hidden />
            </span>
            <span className="font-display text-lg font-bold leading-none tracking-tight">
              WATC<span className="text-primary">?</span>
            </span>
          </Link>
        )}
        <div className="flex items-center gap-1">
          <SoundToggle />
          <StreakBadge />
        </div>
      </div>
    </header>
  )
}
