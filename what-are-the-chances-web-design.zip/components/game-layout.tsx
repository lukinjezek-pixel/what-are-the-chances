import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { SiteHeader } from './site-header'
import { AdSlot } from './ad-slot'
import { GameCard } from './game-card'
import { ACCENT_CLASSES, GAMES, type Game } from '@/lib/games'
import { cn } from '@/lib/utils'

export function GameLayout({
  game,
  children,
}: {
  game: Game
  children: React.ReactNode
}) {
  const accent = ACCENT_CLASSES[game.accent]
  const Icon = game.icon
  const more = GAMES.filter((g) => g.slug !== game.slug).slice(0, 3)

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader back />
      <main className="mx-auto w-full max-w-3xl flex-1 px-4 py-8">
        <div className="mb-6 flex items-center gap-3">
          <span
            className={cn(
              'grid size-12 place-items-center rounded-2xl ring-1',
              accent.softBg,
              accent.text,
              accent.ring,
            )}
          >
            <Icon className="size-6" aria-hidden />
          </span>
          <div>
            <h1 className="font-display text-2xl font-bold leading-tight sm:text-3xl">
              {game.title}
            </h1>
            <p className="text-sm text-muted-foreground">{game.tagline}</p>
          </div>
        </div>

        {/* interactive game surface */}
        <section
          aria-label={`${game.title} game`}
          className="rounded-3xl border border-border/60 bg-card p-5 sm:p-8"
        >
          {children}
        </section>

        {/* SEO-friendly natural description */}
        <section className="prose-invert mt-8">
          <h2 className="font-display text-lg font-bold">About {game.title}</h2>
          <p className="mt-2 leading-relaxed text-muted-foreground">{game.description}</p>
        </section>

        <AdSlot label="Advertisement" className="my-10" />

        <section aria-label="More games">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-display text-lg font-bold">Keep the streak going</h2>
            <Link
              href="/"
              className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline"
            >
              All games
              <ArrowRight className="size-4" aria-hidden />
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {more.map((g) => (
              <GameCard key={g.slug} game={g} />
            ))}
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  )
}

function SiteFooter() {
  return (
    <footer className="border-t border-border/60 py-8 text-center text-xs text-muted-foreground">
      <p>What Are the Chances? — quick games, no gambling, no real-money risk. Just for fun.</p>
    </footer>
  )
}
