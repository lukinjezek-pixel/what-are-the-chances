import { cn } from '@/lib/utils'

type AdSlotProps = {
  /** where this slot sits, used only for the label */
  label?: string
  className?: string
  size?: 'banner' | 'box'
}

/**
 * A clearly-labeled advertising placeholder. It never mimics a real button or
 * game control and is visually separated from interactive UI, so it can be
 * wired to a real ad network later without misleading anyone.
 */
export function AdSlot({ label = 'Advertisement', className, size = 'banner' }: AdSlotProps) {
  return (
    <aside
      aria-label="Advertisement"
      className={cn(
        'mx-auto flex w-full items-center justify-center rounded-2xl border border-dashed border-border/70 bg-muted/30 text-center',
        size === 'banner' ? 'max-w-3xl min-h-24 px-4 py-6' : 'max-w-sm min-h-60 px-4 py-8',
        className,
      )}
    >
      <div className="flex flex-col items-center gap-1">
        <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-muted-foreground/70">
          {label}
        </span>
        <span className="text-sm text-muted-foreground/60">Your ad could be here</span>
      </div>
    </aside>
  )
}
