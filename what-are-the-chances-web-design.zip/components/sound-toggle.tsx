'use client'

import { Volume2, VolumeX } from 'lucide-react'
import { playSound, toggleMuted, useMuted } from '@/lib/sound'

export function SoundToggle() {
  const muted = useMuted()

  return (
    <button
      type="button"
      onClick={() => {
        const nowMuted = toggleMuted()
        // Give audible confirmation when turning sound back on.
        if (!nowMuted) playSound('click')
      }}
      aria-pressed={muted}
      aria-label={muted ? 'Unmute sound effects' : 'Mute sound effects'}
      title={muted ? 'Unmute' : 'Mute'}
      className="inline-flex size-9 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    >
      {muted ? (
        <VolumeX className="size-4" aria-hidden />
      ) : (
        <Volume2 className="size-4" aria-hidden />
      )}
    </button>
  )
}
