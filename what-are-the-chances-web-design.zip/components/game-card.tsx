import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { ACCENT_CLASSES, type Game } from '@/lib/games'
import { cn } from '@/lib/utils'

export function GameCard({ game }: { game: Game }) {
  const accent = ACCENT_CLASSES[game.accent]
  const Icon = game.icon
  return (
    <Link
      href={`/games/${game.slug}`}
      className={cn(
        'group relative flex flex-col gap-3 overflow-hidden rounded-3xl border bg-card p-5 transition-all duration-200',
        'hover:-translate-y-1 hover:shadow-xl hover:shadow-black/30 focus-visible:-translate-y-1',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
        accent.border,
      )}
    >
      <span
        className={cn(
          'grid size-12 place-items-center rounded-2xl ring-1',
          accent.softBg,
          accent.text,
          accent.ring,
        )}
      >
        <Icon className="size-6" aria-hidden />
      </span>
      <div className="flex flex-col gap-1">
        <h3 className="font-display text-lg font-bold leading-tight">{game.title}</h3>
        <p className="text-sm leading-snug text-muted-foreground">{game.tagline}</p>
      </div>
      <span
        className={cn(
          'mt-auto inline-flex items-center gap-1 text-sm font-semibold transition-transform group-hover:translate-x-1',
          accent.text,
        )}
      >
        Play
        <ArrowRight className="size-4" aria-hidden />
      </span>
    </Link>
  )
}
