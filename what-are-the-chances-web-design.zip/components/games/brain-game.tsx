'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { getGame } from '@/lib/games'
import { getBest, markDailyDone, registerPlay, submitScore } from '@/lib/storage'
import { ResultCard } from '@/components/result-card'
import { cn } from '@/lib/utils'

const game = getGame('brain')!
const TIME = 45

type Q = { q: string; options: string[]; answer: number }

const QUESTIONS: Q[] = [
  { q: 'A bat and ball cost £1.10. The bat costs £1 more than the ball. How much is the ball?', options: ['5p', '10p', '1p'], answer: 0 },
  { q: 'Which number is the odd one out?', options: ['9', '16', '25'], answer: 0 },
  { q: 'If you overtake the person in 2nd place, what place are you in?', options: ['1st', '2nd', '3rd'], answer: 1 },
  { q: '2, 6, 12, 20, ? — what comes next?', options: ['30', '28', '24'], answer: 0 },
  { q: 'A farmer has 17 sheep; all but 9 run away. How many are left?', options: ['8', '9', '17'], answer: 1 },
  { q: 'What is half of two plus two?', options: ['2', '3', '4'], answer: 1 },
  { q: 'Which weighs more?', options: ['A kg of feathers', 'A kg of steel', 'They weigh the same'], answer: 2 },
  { q: 'How many months have 28 days?', options: ['1', '2', 'All 12'], answer: 2 },
  { q: 'Some months have 31 days, some 30. How many have 29?', options: ['1', '4', 'All of them (in a leap year)'], answer: 2 },
  { q: 'Mary’s father has 5 daughters: Nana, Nene, Nini, Nono and…?', options: ['Nunu', 'Mary', 'Nana'], answer: 1 },
]

function reaction(correct: number, total: number) {
  const ratio = correct / total
  if (ratio >= 0.9) return "Big brain energy. Almost flawless."
  if (ratio >= 0.7) return "Sharp thinker. Well done."
  if (ratio >= 0.5) return "Not bad — the tricks got a few."
  return "Those trick questions are sneaky. Retry!"
}

export function BrainGame() {
  const [started, setStarted] = useState(false)
  const [index, setIndex] = useState(0)
  const [correct, setCorrect] = useState(0)
  const [picked, setPicked] = useState<number | null>(null)
  const [left, setLeft] = useState(TIME)
  const [done, setDone] = useState(false)
  const [isRecord, setIsRecord] = useState(false)
  const [best, setBest] = useState<number | null>(null)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const quiz = useMemo(() => [...QUESTIONS].sort(() => Math.random() - 0.5).slice(0, 8), [])

  useEffect(() => {
    setBest(getBest('brain'))
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
  }, [])

  const finish = useCallback(
    (score: number) => {
      if (intervalRef.current) clearInterval(intervalRef.current)
      setIsRecord(submitScore('brain', score, 'higher'))
      setBest(getBest('brain'))
      registerPlay()
      markDailyDone('brain')
      setDone(true)
    },
    [],
  )

  function begin() {
    setStarted(true)
    const startedAt = Date.now()
    intervalRef.current = setInterval(() => {
      const remaining = Math.max(0, TIME - Math.floor((Date.now() - startedAt) / 1000))
      setLeft(remaining)
      if (remaining <= 0) setCorrect((c) => (finish(c), c))
    }, 250)
  }

  function pick(i: number) {
    if (picked !== null) return
    setPicked(i)
    const right = i === quiz[index].answer
    const nextCorrect = correct + (right ? 1 : 0)
    setTimeout(() => {
      if (index + 1 >= quiz.length) {
        setCorrect(nextCorrect)
        finish(nextCorrect)
      } else {
        setCorrect(nextCorrect)
        setIndex(index + 1)
        setPicked(null)
      }
    }, 700)
  }

  function reset() {
    setStarted(false)
    setIndex(0)
    setCorrect(0)
    setPicked(null)
    setLeft(TIME)
    setDone(false)
    setIsRecord(false)
  }

  if (done) {
    return (
      <ResultCard
        game={game}
        scoreValue={`${correct}/${quiz.length}`}
        scoreCaption="correct answers"
        reaction={reaction(correct, quiz.length)}
        shareLine={`I got ${correct}/${quiz.length} on the Brain Test`}
        isRecord={isRecord}
        best={best != null ? `${best} correct` : null}
        onTryAgain={reset}
      />
    )
  }

  if (!started) {
    return (
      <div className="flex flex-col items-center gap-6 text-center">
        <div>
          <p className="font-display text-2xl font-bold">Beat the clock</p>
          <p className="max-w-xs text-balance text-sm text-muted-foreground">
            {quiz.length} quick logic &amp; trick questions in {TIME} seconds. Read carefully — they&apos;re sneaky.
          </p>
        </div>
        <button
          type="button"
          onClick={begin}
          className="inline-flex h-14 items-center rounded-2xl bg-primary px-10 text-lg font-bold text-primary-foreground transition-transform hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          Start
        </button>
        {best != null && (
          <span className="text-sm text-muted-foreground">Best: {best} correct</span>
        )}
      </div>
    )
  }

  const current = quiz[index]

  return (
    <div className="flex flex-col items-center gap-5 text-center">
      <div className="flex w-full items-center justify-between text-sm font-semibold">
        <span className="text-muted-foreground">
          {index + 1} / {quiz.length}
        </span>
        <span className={cn(left <= 10 && 'text-destructive')}>{left}s</span>
      </div>

      <div className="flex min-h-28 w-full items-center justify-center rounded-2xl border border-cyan/30 bg-cyan/10 p-5">
        <p className="text-balance font-display text-xl font-bold leading-snug">{current.q}</p>
      </div>

      <div className="grid w-full gap-2.5">
        {current.options.map((opt, i) => {
          const revealed = picked !== null
          const isAnswer = i === current.answer
          const isPicked = picked === i
          return (
            <button
              key={i}
              type="button"
              disabled={revealed}
              onClick={() => pick(i)}
              className={cn(
                'flex min-h-14 items-center justify-center rounded-2xl border px-4 py-3 text-base font-semibold transition-all',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
                !revealed && 'border-border/60 bg-muted/30 hover:-translate-y-0.5 hover:border-cyan/40 hover:bg-cyan/10',
                revealed && isAnswer && 'border-lime/50 bg-lime/20 text-lime',
                revealed && !isAnswer && isPicked && 'border-destructive/50 bg-destructive/15 text-destructive',
                revealed && !isAnswer && !isPicked && 'border-border/40 opacity-50',
              )}
            >
              {opt}
            </button>
          )
        })}
      </div>
    </div>
  )
}
