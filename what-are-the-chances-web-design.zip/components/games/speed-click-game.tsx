'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { getGame } from '@/lib/games'
import { getBest, markDailyDone, registerPlay, submitScore } from '@/lib/storage'
import { ResultCard } from '@/components/result-card'
import { cn } from '@/lib/utils'

const game = getGame('speed-click')!
const DURATION = 10

function reaction(clicks: number) {
  if (clicks > 90) return "Are your fingers okay?? Incredible."
  if (clicks > 70) return "Machine-gun fingers. Very impressive."
  if (clicks > 50) return "Fast and furious. Nicely done."
  if (clicks > 30) return "Respectable clicking. Solid effort."
  return "Warm up those fingers and go again!"
}

export function SpeedClickGame() {
  const [phase, setPhase] = useState<'idle' | 'running' | 'result'>('idle')
  const [count, setCount] = useState(0)
  const [left, setLeft] = useState(DURATION)
  const [isRecord, setIsRecord] = useState(false)
  const [best, setBest] = useState<number | null>(null)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => {
    setBest(getBest('speed-click'))
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
  }, [])

  const finish = useCallback((final: number) => {
    if (intervalRef.current) clearInterval(intervalRef.current)
    setIsRecord(submitScore('speed-click', final, 'higher'))
    setBest(getBest('speed-click'))
    registerPlay()
    markDailyDone('speed-click')
    setPhase('result')
  }, [])

  const tap = useCallback(() => {
    if (phase === 'idle') {
      setCount(1)
      setLeft(DURATION)
      setPhase('running')
      const startedAt = Date.now()
      intervalRef.current = setInterval(() => {
        const elapsed = (Date.now() - startedAt) / 1000
        const remaining = Math.max(0, DURATION - elapsed)
        setLeft(remaining)
        if (remaining <= 0) {
          setCount((c) => {
            finish(c)
            return c
          })
        }
      }, 50)
    } else if (phase === 'running') {
      setCount((c) => c + 1)
    }
  }, [phase, finish])

  if (phase === 'result') {
    return (
      <ResultCard
        game={game}
        scoreValue={`${count}`}
        scoreCaption={`clicks in ${DURATION} seconds`}
        reaction={reaction(count)}
        shareLine={`I clicked ${count} times in ${DURATION}s`}
        isRecord={isRecord}
        best={best != null ? `${best} clicks` : null}
        onTryAgain={() => {
          setCount(0)
          setLeft(DURATION)
          setPhase('idle')
        }}
      />
    )
  }

  const pct = (left / DURATION) * 100

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex w-full items-center justify-between text-sm font-semibold">
        <span className="text-muted-foreground">
          {phase === 'idle' ? 'Ready' : 'Go go go!'}
        </span>
        <span className={cn(left <= 3 && phase === 'running' && 'text-destructive')}>
          {left.toFixed(1)}s
        </span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
        <div
          className="h-full rounded-full bg-gold transition-[width] duration-75 ease-linear"
          style={{ width: `${pct}%` }}
        />
      </div>
      <button
        type="button"
        onClick={tap}
        className={cn(
          'flex min-h-[20rem] w-full select-none flex-col items-center justify-center gap-2 rounded-2xl text-center transition-transform active:scale-[0.99] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:min-h-[24rem]',
          phase === 'running' ? 'bg-gold/15 text-gold' : 'bg-muted/40 text-foreground',
        )}
      >
        <span className="font-display text-7xl font-bold tabular-nums sm:text-8xl">{count}</span>
        <span className="text-base opacity-80">
          {phase === 'idle' ? 'Tap anywhere to begin' : 'Keep tapping!'}
        </span>
      </button>
      {best != null && phase === 'idle' && (
        <span className="rounded-full bg-muted px-3 py-1 text-sm font-semibold">
          Best: {best} clicks
        </span>
      )}
    </div>
  )
}
