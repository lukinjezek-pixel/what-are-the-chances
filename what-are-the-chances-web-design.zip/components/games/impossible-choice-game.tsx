'use client'

import { useEffect, useMemo, useState } from 'react'
import { getGame } from '@/lib/games'
import { markDailyDone, registerPlay, submitScore, getBest } from '@/lib/storage'
import { ResultCard } from '@/components/result-card'
import { cn } from '@/lib/utils'

const game = getGame('impossible-choice')!

type Dilemma = { a: string; b: string; aPct: number }

const DILEMMAS: Dilemma[] = [
  { a: 'Always be 10 minutes late', b: 'Always be 20 minutes early', aPct: 62 },
  { a: 'Have no internet for a week', b: 'Have no music for a month', aPct: 48 },
  { a: 'Fight one horse-sized duck', b: 'Fight 100 duck-sized horses', aPct: 55 },
  { a: 'Know how you die', b: 'Know when you die', aPct: 40 },
  { a: 'Be able to fly', b: 'Be able to turn invisible', aPct: 71 },
  { a: 'Never read a new book again', b: 'Never watch a new film again', aPct: 44 },
  { a: 'Speak every language', b: 'Play every instrument', aPct: 66 },
  { a: 'Relive your best day forever', b: 'Get a brand-new random day', aPct: 33 },
]

function reaction(bold: number, total: number) {
  const ratio = bold / total
  if (ratio >= 0.7) return "You are wildly contrarian. Chaos incarnate."
  if (ratio >= 0.45) return "You march to your own beat. Interesting."
  if (ratio >= 0.2) return "Mostly with the crowd, occasionally rogue."
  return "You and the crowd think exactly alike."
}

export function ImpossibleChoiceGame() {
  const [index, setIndex] = useState(0)
  const [bold, setBold] = useState(0) // times you picked the minority option
  const [reveal, setReveal] = useState<{ pick: 'a' | 'b'; aPct: number } | null>(null)
  const [done, setDone] = useState(false)
  const [isRecord, setIsRecord] = useState(false)
  const [best, setBest] = useState<number | null>(null)

  const order = useMemo(
    () => [...DILEMMAS].sort(() => Math.random() - 0.5),
    [],
  )

  useEffect(() => {
    setBest(getBest('impossible-choice'))
  }, [])

  const total = order.length
  const current = order[index]

  function reset() {
    setIndex(0)
    setBold(0)
    setReveal(null)
    setDone(false)
    setIsRecord(false)
  }

  function pick(choice: 'a' | 'b') {
    if (reveal) return
    const pct = choice === 'a' ? current.aPct : 100 - current.aPct
    const minority = pct < 50
    const nextBold = bold + (minority ? 1 : 0)
    setReveal({ pick: choice, aPct: current.aPct })
    setTimeout(() => {
      if (index + 1 >= total) {
        setBold(nextBold)
        setIsRecord(submitScore('impossible-choice', nextBold, 'higher'))
        setBest(getBest('impossible-choice'))
        registerPlay()
        markDailyDone('impossible-choice')
        setDone(true)
      } else {
        setBold(nextBold)
        setIndex(index + 1)
        setReveal(null)
      }
    }, 1100)
  }

  if (done) {
    return (
      <ResultCard
        game={game}
        scoreValue={`${bold}/${total}`}
        scoreCaption="rogue picks (against the crowd)"
        reaction={reaction(bold, total)}
        shareLine={`I went against the crowd ${bold}/${total} times`}
        isRecord={isRecord}
        best={best != null ? `${best}/${total}` : null}
        onTryAgain={reset}
      />
    )
  }

  const options: { key: 'a' | 'b'; label: string; pct: number }[] = [
    { key: 'a', label: current.a, pct: current.aPct },
    { key: 'b', label: current.b, pct: 100 - current.aPct },
  ]

  return (
    <div className="flex flex-col items-center gap-6 text-center">
      <div className="flex w-full items-center justify-between text-sm font-semibold text-muted-foreground">
        <span>
          {index + 1} / {total}
        </span>
        <span>Would you rather…</span>
      </div>

      <div className="grid w-full gap-3 sm:grid-cols-2">
        {options.map((opt) => {
          const chosen = reveal?.pick === opt.key
          return (
            <button
              key={opt.key}
              type="button"
              disabled={!!reveal}
              onClick={() => pick(opt.key)}
              className={cn(
                'group relative flex min-h-40 flex-col items-center justify-center gap-3 rounded-2xl border p-6 text-center transition-all',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
                reveal
                  ? chosen
                    ? 'border-pink/50 bg-pink/15'
                    : 'border-border/50 opacity-60'
                  : 'border-border/60 bg-muted/30 hover:-translate-y-0.5 hover:border-pink/40 hover:bg-pink/10',
              )}
            >
              <span className="text-balance font-display text-lg font-bold leading-snug">
                {opt.label}
              </span>
              {reveal && (
                <span className="text-sm font-semibold text-muted-foreground">
                  {opt.pct}% chose this
                </span>
              )}
            </button>
          )
        })}
      </div>
      <p className="text-xs text-muted-foreground">Crowd percentages are just for fun.</p>
    </div>
  )
}
