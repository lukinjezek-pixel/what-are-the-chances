'use client'

import { useEffect, useState } from 'react'
import { Check, SkipForward, Flag } from 'lucide-react'
import { getGame } from '@/lib/games'
import { getBest, markDailyDone, registerPlay, submitScore } from '@/lib/storage'
import { ResultCard } from '@/components/result-card'
import { Button } from '@/components/ui/button'

const game = getGame('random-challenge')!

const CHALLENGES = [
  'Text an old friend just to say hi.',
  'Do 15 push-ups right now.',
  'Give someone a genuine compliment today.',
  'Take a cold shower this evening.',
  'Learn to say hello in a new language.',
  'Go 1 hour with your phone in another room.',
  'Try writing your name with your other hand.',
  'Take the stairs instead of the lift all day.',
  'Drink a full glass of water right now.',
  'Tidy one small drawer or shelf.',
  'Message someone you appreciate and tell them.',
  'Do a 60-second plank.',
  'Step outside and take 10 deep breaths.',
  'Learn one weird fact and share it with someone.',
  'Do the dishes before anyone asks.',
  'Stretch for 2 minutes without stopping.',
]

function pick(exclude?: string) {
  let c = CHALLENGES[Math.floor(Math.random() * CHALLENGES.length)]
  while (c === exclude && CHALLENGES.length > 1) {
    c = CHALLENGES[Math.floor(Math.random() * CHALLENGES.length)]
  }
  return c
}

function reaction(n: number) {
  if (n >= 8) return "Unstoppable. Nothing scares you."
  if (n >= 5) return "Bold mover. Great energy today."
  if (n >= 2) return "Nice — you took on a few dares."
  if (n === 1) return "One down. Baby steps count!"
  return "Skipped them all? Live a little!"
}

export function RandomChallengeGame() {
  const [challenge, setChallenge] = useState('')
  const [accepted, setAccepted] = useState(0)
  const [done, setDone] = useState(false)
  const [isRecord, setIsRecord] = useState(false)
  const [best, setBest] = useState<number | null>(null)

  useEffect(() => {
    setChallenge(pick())
    setBest(getBest('random-challenge'))
  }, [])

  function reset() {
    setChallenge(pick())
    setAccepted(0)
    setDone(false)
    setIsRecord(false)
  }

  function accept() {
    setAccepted((a) => a + 1)
    setChallenge((c) => pick(c))
  }

  function skip() {
    setChallenge((c) => pick(c))
  }

  function finish() {
    setIsRecord(submitScore('random-challenge', accepted, 'higher'))
    setBest(getBest('random-challenge'))
    registerPlay()
    markDailyDone('random-challenge')
    setDone(true)
  }

  if (done) {
    return (
      <ResultCard
        game={game}
        scoreValue={`${accepted}`}
        scoreCaption={accepted === 1 ? 'dare accepted' : 'dares accepted'}
        reaction={reaction(accepted)}
        shareLine={`I accepted ${accepted} random dares`}
        isRecord={isRecord}
        best={best != null ? `${best} dares` : null}
        onTryAgain={reset}
      />
    )
  }

  return (
    <div className="flex flex-col items-center gap-6 text-center">
      <div className="flex w-full items-center justify-between text-sm font-semibold text-muted-foreground">
        <span>Your dare</span>
        <span>{accepted} accepted</span>
      </div>

      <div className="flex min-h-48 w-full items-center justify-center rounded-2xl border border-pink/30 bg-pink/10 p-8">
        <p className="text-balance font-display text-2xl font-bold leading-snug sm:text-3xl">
          {challenge}
        </p>
      </div>

      <div className="grid w-full grid-cols-2 gap-3">
        <Button
          size="lg"
          onClick={accept}
          className="h-14 rounded-2xl text-base font-bold"
        >
          <Check className="size-5" aria-hidden />
          I did it!
        </Button>
        <Button
          size="lg"
          variant="secondary"
          onClick={skip}
          className="h-14 rounded-2xl text-base font-bold"
        >
          <SkipForward className="size-5" aria-hidden />
          Skip
        </Button>
      </div>

      <Button
        variant="ghost"
        onClick={finish}
        className="text-muted-foreground hover:text-foreground"
      >
        <Flag className="size-4" aria-hidden />
        Finish & see result
      </Button>

      {best != null && (
        <span className="text-sm text-muted-foreground">Best: {best} dares</span>
      )}
    </div>
  )
}
