'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { getGame } from '@/lib/games'
import { getBest, markDailyDone, registerPlay, submitScore } from '@/lib/storage'
import { ResultCard } from '@/components/result-card'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

const game = getGame('memory')!

const TILES = [
  { base: 'bg-lime/20', lit: 'bg-lime' },
  { base: 'bg-pink/20', lit: 'bg-pink' },
  { base: 'bg-cyan/20', lit: 'bg-cyan' },
  { base: 'bg-gold/20', lit: 'bg-gold' },
]

function reaction(level: number) {
  if (level >= 12) return "Photographic memory confirmed."
  if (level >= 9) return "Elephant-tier recall. Amazing."
  if (level >= 6) return "Great memory — sharper than most."
  if (level >= 4) return "Not bad at all. Keep training."
  return "Warming up? Give it another go."
}

export function MemoryGame() {
  const [phase, setPhase] = useState<'idle' | 'showing' | 'input' | 'result'>('idle')
  const [sequence, setSequence] = useState<number[]>([])
  const [step, setStep] = useState(0)
  const [lit, setLit] = useState<number | null>(null)
  const [level, setLevel] = useState(0)
  const [isRecord, setIsRecord] = useState(false)
  const [best, setBest] = useState<number | null>(null)
  const timers = useRef<ReturnType<typeof setTimeout>[]>([])

  useEffect(() => {
    setBest(getBest('memory'))
    return () => timers.current.forEach(clearTimeout)
  }, [])

  const playback = useCallback((seq: number[]) => {
    setPhase('showing')
    timers.current.forEach(clearTimeout)
    timers.current = []
    seq.forEach((tile, i) => {
      timers.current.push(
        setTimeout(() => setLit(tile), 600 * i + 250),
        setTimeout(() => setLit(null), 600 * i + 650),
      )
    })
    timers.current.push(
      setTimeout(() => {
        setStep(0)
        setPhase('input')
      }, 600 * seq.length + 300),
    )
  }, [])

  const startRound = useCallback(
    (prev: number[]) => {
      const next = [...prev, Math.floor(Math.random() * 4)]
      setSequence(next)
      playback(next)
    },
    [playback],
  )

  function begin() {
    setLevel(0)
    setIsRecord(false)
    startRound([])
  }

  function endGame(reached: number) {
    setLevel(reached)
    setIsRecord(submitScore('memory', reached, 'higher'))
    setBest(getBest('memory'))
    registerPlay()
    markDailyDone('memory')
    setPhase('result')
  }

  function press(tile: number) {
    if (phase !== 'input') return
    // brief flash for feedback
    setLit(tile)
    timers.current.push(setTimeout(() => setLit(null), 180))

    if (tile === sequence[step]) {
      if (step + 1 === sequence.length) {
        // completed this sequence -> level up
        setLevel(sequence.length)
        timers.current.push(setTimeout(() => startRound(sequence), 500))
      } else {
        setStep(step + 1)
      }
    } else {
      endGame(sequence.length - 1)
    }
  }

  if (phase === 'result') {
    return (
      <ResultCard
        game={game}
        scoreValue={`Level ${level}`}
        scoreCaption={`remembered ${level} in a row`}
        reaction={reaction(level)}
        shareLine={`I hit level ${level} on Memory Test`}
        isRecord={isRecord}
        best={best != null ? `Level ${best}` : null}
        onTryAgain={begin}
      />
    )
  }

  return (
    <div className="flex flex-col items-center gap-6 text-center">
      <div className="flex w-full items-center justify-between text-sm font-semibold">
        <span className="text-muted-foreground">
          {phase === 'showing' ? 'Watch closely…' : phase === 'input' ? 'Your turn!' : 'Ready?'}
        </span>
        <span>Level {phase === 'idle' ? 0 : sequence.length}</span>
      </div>

      <div className="grid w-full max-w-xs grid-cols-2 gap-3">
        {TILES.map((t, i) => (
          <button
            key={i}
            type="button"
            disabled={phase !== 'input'}
            onClick={() => press(i)}
            aria-label={`Tile ${i + 1}`}
            className={cn(
              'aspect-square rounded-2xl transition-all duration-150',
              lit === i ? `${t.lit} scale-95` : t.base,
              phase === 'input' && 'hover:brightness-125 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
            )}
          />
        ))}
      </div>

      {phase === 'idle' && (
        <>
          <Button size="lg" onClick={begin} className="h-14 rounded-2xl px-8 text-base font-bold">
            Start
          </Button>
          {best != null && (
            <span className="text-sm text-muted-foreground">Best: Level {best}</span>
          )}
        </>
      )}
    </div>
  )
}
