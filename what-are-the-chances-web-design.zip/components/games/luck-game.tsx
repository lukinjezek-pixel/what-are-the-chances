'use client'

import { useEffect, useState } from 'react'
import { Gift, Check, X } from 'lucide-react'
import { getGame } from '@/lib/games'
import { getBest, markDailyDone, registerPlay, submitScore } from '@/lib/storage'
import { ResultCard } from '@/components/result-card'
import { cn } from '@/lib/utils'

const game = getGame('luck')!
const ROUNDS = 5
const BOXES = 3

function reaction(luck: number) {
  if (luck === 100) return "The universe adores you today."
  if (luck >= 80) return "Incredibly lucky. Go buy a lottery ticket. (Kidding.)"
  if (luck >= 60) return "Fortune is smiling on you."
  if (luck >= 40) return "Perfectly average luck. Balanced."
  if (luck >= 20) return "A rough streak. It can only go up."
  return "Yikes. Stay indoors, maybe?"
}

export function LuckGame() {
  const [round, setRound] = useState(0)
  const [wins, setWins] = useState(0)
  const [lucky, setLucky] = useState(0)
  const [picked, setPicked] = useState<number | null>(null)
  const [done, setDone] = useState(false)
  const [isRecord, setIsRecord] = useState(false)
  const [best, setBest] = useState<number | null>(null)

  useEffect(() => {
    setLucky(Math.floor(Math.random() * BOXES))
    setBest(getBest('luck'))
  }, [])

  function reset() {
    setRound(0)
    setWins(0)
    setPicked(null)
    setLucky(Math.floor(Math.random() * BOXES))
    setDone(false)
    setIsRecord(false)
  }

  function choose(i: number) {
    if (picked !== null) return
    setPicked(i)
    const won = i === lucky
    const nextWins = wins + (won ? 1 : 0)
    setTimeout(() => {
      if (round + 1 >= ROUNDS) {
        const luck = Math.round((nextWins / ROUNDS) * 100)
        setWins(nextWins)
        setIsRecord(submitScore('luck', luck, 'higher'))
        setBest(getBest('luck'))
        registerPlay()
        markDailyDone('luck')
        setDone(true)
      } else {
        setWins(nextWins)
        setRound(round + 1)
        setPicked(null)
        setLucky(Math.floor(Math.random() * BOXES))
      }
    }, 950)
  }

  if (done) {
    const luck = Math.round((wins / ROUNDS) * 100)
    return (
      <ResultCard
        game={game}
        scoreValue={`${luck}`}
        scoreCaption={`luck rating · ${wins}/${ROUNDS} correct`}
        reaction={reaction(luck)}
        shareLine={`My luck rating today is ${luck}/100`}
        isRecord={isRecord}
        best={best != null ? `${best}/100` : null}
        onTryAgain={reset}
      />
    )
  }

  return (
    <div className="flex flex-col items-center gap-6 text-center">
      <div className="flex w-full items-center justify-between text-sm font-semibold text-muted-foreground">
        <span>
          Round {round + 1} / {ROUNDS}
        </span>
        <span>{wins} lucky</span>
      </div>

      <p className="font-display text-xl font-bold">Pick the lucky box</p>

      <div className="grid w-full grid-cols-3 gap-3">
        {Array.from({ length: BOXES }).map((_, i) => {
          const revealed = picked !== null
          const isLucky = i === lucky
          const isPicked = picked === i
          return (
            <button
              key={i}
              type="button"
              disabled={revealed}
              onClick={() => choose(i)}
              aria-label={`Box ${i + 1}`}
              className={cn(
                'flex aspect-square items-center justify-center rounded-2xl border transition-all duration-200',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
                !revealed && 'border-border/60 bg-muted/40 hover:-translate-y-1 hover:border-lime/40 hover:bg-lime/10',
                revealed && isLucky && 'border-lime/50 bg-lime/20 text-lime',
                revealed && !isLucky && isPicked && 'border-destructive/50 bg-destructive/15 text-destructive',
                revealed && !isLucky && !isPicked && 'border-border/40 opacity-50',
              )}
            >
              {revealed ? (
                isLucky ? (
                  <Check className="size-9" aria-hidden />
                ) : isPicked ? (
                  <X className="size-9" aria-hidden />
                ) : (
                  <Gift className="size-9 opacity-40" aria-hidden />
                )
              ) : (
                <Gift className="size-9 text-muted-foreground" aria-hidden />
              )}
            </button>
          )
        })}
      </div>

      {best != null && (
        <span className="text-sm text-muted-foreground">Best: {best}/100</span>
      )}
    </div>
  )
}
