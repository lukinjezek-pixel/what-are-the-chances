'use client'

import { useEffect, useRef, useState } from 'react'
import { ArrowDown, ArrowUp } from 'lucide-react'
import { getGame } from '@/lib/games'
import { getBest, markDailyDone, registerPlay, submitScore } from '@/lib/storage'
import { ResultCard } from '@/components/result-card'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

const game = getGame('number-guess')!

function secret() {
  return Math.floor(Math.random() * 100) + 1
}

function reaction(tries: number) {
  if (tries <= 4) return "Mind reader. That was scary good."
  if (tries <= 6) return "Sharp deduction. Well played."
  if (tries <= 8) return "Got there in the end — solid."
  return "Phew, that took a while. Try to beat it!"
}

export function NumberGuessGame() {
  const [target, setTarget] = useState<number>(0)
  const [value, setValue] = useState('')
  const [tries, setTries] = useState(0)
  const [hint, setHint] = useState<'higher' | 'lower' | null>(null)
  const [history, setHistory] = useState<number[]>([])
  const [done, setDone] = useState(false)
  const [isRecord, setIsRecord] = useState(false)
  const [best, setBest] = useState<number | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    setTarget(secret())
    setBest(getBest('number-guess'))
  }, [])

  function reset() {
    setTarget(secret())
    setValue('')
    setTries(0)
    setHint(null)
    setHistory([])
    setDone(false)
    setIsRecord(false)
  }

  function guess(e: React.FormEvent) {
    e.preventDefault()
    const n = Number(value)
    if (!Number.isInteger(n) || n < 1 || n > 100) return
    const next = tries + 1
    setTries(next)
    setHistory((h) => [n, ...h].slice(0, 6))
    if (n === target) {
      setIsRecord(submitScore('number-guess', next, 'lower'))
      setBest(getBest('number-guess'))
      registerPlay()
      markDailyDone('number-guess')
      setDone(true)
    } else {
      setHint(n < target ? 'higher' : 'lower')
      setValue('')
      inputRef.current?.focus()
    }
  }

  if (done) {
    return (
      <ResultCard
        game={game}
        scoreValue={`${tries}`}
        scoreCaption={tries === 1 ? 'guess' : 'guesses'}
        reaction={reaction(tries)}
        shareLine={`I found the number in ${tries} guesses`}
        isRecord={isRecord}
        best={best != null ? `${best} guesses` : null}
        onTryAgain={reset}
      />
    )
  }

  return (
    <div className="flex flex-col items-center gap-6 text-center">
      <div>
        <p className="font-display text-2xl font-bold">Guess the number</p>
        <p className="text-sm text-muted-foreground">Somewhere between 1 and 100.</p>
      </div>

      <div
        className={cn(
          'flex min-h-24 w-full max-w-sm flex-col items-center justify-center gap-1 rounded-2xl border p-4',
          hint ? 'border-cyan/30 bg-cyan/10 text-cyan' : 'border-border/60 bg-muted/30',
        )}
      >
        {hint ? (
          <span className="inline-flex items-center gap-2 font-display text-2xl font-bold">
            {hint === 'higher' ? (
              <ArrowUp className="size-6" aria-hidden />
            ) : (
              <ArrowDown className="size-6" aria-hidden />
            )}
            Go {hint}
          </span>
        ) : (
          <span className="text-muted-foreground">Make your first guess</span>
        )}
        <span className="text-sm text-muted-foreground">
          {tries} {tries === 1 ? 'guess' : 'guesses'} so far
        </span>
      </div>

      <form onSubmit={guess} className="flex w-full max-w-sm items-center gap-2">
        <input
          ref={inputRef}
          type="number"
          inputMode="numeric"
          min={1}
          max={100}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="1–100"
          aria-label="Your guess"
          className="h-14 flex-1 rounded-2xl border border-border bg-background px-4 text-center font-display text-2xl font-bold tabular-nums outline-none focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/50"
        />
        <Button type="submit" size="lg" className="h-14 rounded-2xl px-6 text-base font-bold">
          Guess
        </Button>
      </form>

      {history.length > 0 && (
        <div className="flex flex-wrap items-center justify-center gap-2">
          {history.map((h, i) => (
            <span
              key={`${h}-${i}`}
              className="rounded-lg bg-muted px-2.5 py-1 text-sm font-semibold tabular-nums text-muted-foreground"
            >
              {h}
            </span>
          ))}
        </div>
      )}

      {best != null && (
        <span className="text-sm text-muted-foreground">Best: {best} guesses</span>
      )}
    </div>
  )
}
