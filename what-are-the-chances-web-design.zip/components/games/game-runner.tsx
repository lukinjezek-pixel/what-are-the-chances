'use client'

import { ReactionGame } from './reaction-game'
import { ImpossibleChoiceGame } from './impossible-choice-game'
import { NumberGuessGame } from './number-guess-game'
import { MemoryGame } from './memory-game'
import { SpeedClickGame } from './speed-click-game'
import { RandomChallengeGame } from './random-challenge-game'
import { LuckGame } from './luck-game'
import { BrainGame } from './brain-game'

export function GameRunner({ slug }: { slug: string }) {
  switch (slug) {
    case 'reaction':
      return <ReactionGame />
    case 'impossible-choice':
      return <ImpossibleChoiceGame />
    case 'number-guess':
      return <NumberGuessGame />
    case 'memory':
      return <MemoryGame />
    case 'speed-click':
      return <SpeedClickGame />
    case 'random-challenge':
      return <RandomChallengeGame />
    case 'luck':
      return <LuckGame />
    case 'brain':
      return <BrainGame />
    default:
      return null
  }
}
