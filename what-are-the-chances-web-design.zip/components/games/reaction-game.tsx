'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { getGame } from '@/lib/games'
import { getBest, markDailyDone, registerPlay, submitScore } from '@/lib/storage'
import { ResultCard } from '@/components/result-card'
import { cn } from '@/lib/utils'

const game = getGame('reaction')!

type Phase = 'idle' | 'waiting' | 'ready' | 'tooSoon' | 'result'

function reaction(ms: number) {
  if (ms < 200) return "Inhuman. Are you even blinking?"
  if (ms < 260) return "Pro-gamer reflexes. Terrifying."
  if (ms < 350) return "Sharp. Faster than most people alive."
  if (ms < 450) return "Solid, totally respectable."
  return "A little sleepy today? Try again."
}

export function ReactionGame() {
  const [phase, setPhase] = useState<Phase>('idle')
  const [ms, setMs] = useState(0)
  const [isRecord, setIsRecord] = useState(false)
  const [best, setBest] = useState<number | null>(null)
  const startRef = useRef(0)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    setBest(getBest('reaction'))
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current)
    }
  }, [])

  const start = useCallback(() => {
    setPhase('waiting')
    const delay = 1400 + Math.random() * 2800
    timerRef.current = setTimeout(() => {
      startRef.current = performance.now()
      setPhase('ready')
    }, delay)
  }, [])

  const handleClick = useCallback(() => {
    if (phase === 'idle' || phase === 'tooSoon') {
      start()
    } else if (phase === 'waiting') {
      if (timerRef.current) clearTimeout(timerRef.current)
      setPhase('tooSoon')
    } else if (phase === 'ready') {
      const value = Math.round(performance.now() - startRef.current)
      setMs(value)
      setIsRecord(submitScore('reaction', value, 'lower'))
      setBest(getBest('reaction'))
      registerPlay()
      markDailyDone('reaction')
      setPhase('result')
    }
  }, [phase, start])

  if (phase === 'result') {
    return (
      <ResultCard
        game={game}
        scoreValue={`${ms} ms`}
        scoreCaption="reaction time"
        reaction={reaction(ms)}
        shareLine={`I reacted in ${ms}ms`}
        isRecord={isRecord}
        best={best != null ? `${best} ms` : null}
        onTryAgain={() => setPhase('idle')}
      />
    )
  }

  const styles: Record<Exclude<Phase, 'result'>, string> = {
    idle: 'bg-muted/40 text-foreground',
    waiting: 'bg-destructive/20 text-destructive',
    ready: 'bg-lime text-black',
    tooSoon: 'bg-secondary text-foreground',
  }

  const copy: Record<Exclude<Phase, 'result'>, { big: string; small: string }> = {
    idle: { big: 'Tap to start', small: 'Wait for green, then tap as fast as you can' },
    waiting: { big: 'Wait…', small: 'Hold on until it turns green' },
    ready: { big: 'TAP!', small: 'Now!' },
    tooSoon: { big: 'Too soon!', small: 'You tapped before green. Tap to retry' },
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      className={cn(
        'flex min-h-[22rem] w-full flex-col items-center justify-center gap-2 rounded-2xl text-center transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:min-h-[26rem]',
        styles[phase],
      )}
    >
      <span className="font-display text-5xl font-bold sm:text-6xl">{copy[phase].big}</span>
      <span className="max-w-xs text-balance text-base opacity-80">{copy[phase].small}</span>
      {best != null && phase === 'idle' && (
        <span className="mt-4 rounded-full bg-background/40 px-3 py-1 text-sm font-semibold">
          Best: {best} ms
        </span>
      )}
    </button>
  )
}
