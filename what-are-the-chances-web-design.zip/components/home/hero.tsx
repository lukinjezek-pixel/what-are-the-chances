import Link from 'next/link'
import { Play } from 'lucide-react'
import { GAMES } from '@/lib/games'

export function Hero({ startHref }: { startHref: string }) {
  // a few icons floating in the background for playful energy
  const floaters = GAMES.slice(0, 6)

  return (
    <section className="relative overflow-hidden px-4 pt-14 pb-16 sm:pt-20 sm:pb-24">
      {/* glow */}
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-0 h-72 w-72 -translate-x-1/2 rounded-full bg-primary/25 blur-[100px]"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute right-6 top-24 hidden gap-6 sm:flex"
      >
        {floaters.slice(0, 3).map((g, i) => {
          const Icon = g.icon
          return (
            <span
              key={g.slug}
              className="animate-float-slow text-muted-foreground/25"
              style={{ animationDelay: `${i * 0.8}s` }}
            >
              <Icon className="size-10" />
            </span>
          )
        })}
      </div>

      <div className="relative mx-auto flex max-w-3xl flex-col items-center text-center">
        <span className="mb-5 inline-flex items-center gap-2 rounded-full border border-border/70 bg-card/60 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.15em] text-muted-foreground">
          {GAMES.length} games · under 2 minutes each
        </span>
        <h1 className="font-display text-5xl font-bold leading-[0.95] tracking-tight text-balance sm:text-7xl">
          WHAT ARE THE{' '}
          <span className="bg-gradient-to-r from-primary via-pink to-cyan bg-clip-text text-transparent">
            CHANCES?
          </span>
        </h1>
        <p className="mt-5 max-w-md text-balance text-lg text-muted-foreground sm:text-xl">
          Test yourself. Challenge your friends.
        </p>
        <Link
          href={startHref}
          className="mt-8 inline-flex h-16 items-center gap-2 rounded-2xl bg-primary px-12 text-xl font-bold text-primary-foreground shadow-lg shadow-primary/30 transition-all hover:-translate-y-0.5 hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background active:translate-y-0"
        >
          <Play className="size-6 fill-current" aria-hidden />
          START
        </Link>
        <p className="mt-4 text-sm text-muted-foreground">
          Free · No sign-up · Works on any phone
        </p>
      </div>
    </section>
  )
}
