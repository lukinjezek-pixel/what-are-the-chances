'use client'

import Link from 'next/link'
import { useEffect, useState } from 'react'
import { CalendarDays, Check, ArrowRight } from 'lucide-react'
import { ACCENT_CLASSES, getGame } from '@/lib/games'
import { isDailyDone } from '@/lib/storage'
import { cn } from '@/lib/utils'

export function DailyChallenge({ slug }: { slug: string }) {
  const game = getGame(slug)!
  const accent = ACCENT_CLASSES[game.accent]
  const Icon = game.icon
  const [done, setDone] = useState(false)

  useEffect(() => {
    setDone(isDailyDone(game.slug))
  }, [game.slug])

  return (
    <Link
      href={`/games/${game.slug}`}
      className={cn(
        'group relative flex items-center gap-4 overflow-hidden rounded-3xl border bg-card p-5 transition-all hover:-translate-y-0.5 hover:shadow-xl hover:shadow-black/30 sm:p-6',
        accent.border,
      )}
    >
      <div
        aria-hidden
        className={cn('absolute -right-8 -top-8 size-32 rounded-full blur-2xl', accent.softBg)}
      />
      <span
        className={cn(
          'relative grid size-16 shrink-0 place-items-center rounded-2xl ring-1',
          accent.softBg,
          accent.text,
          accent.ring,
        )}
      >
        <Icon className="size-8" aria-hidden />
      </span>
      <div className="relative flex-1">
        <span className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-[0.15em] text-muted-foreground">
          <CalendarDays className="size-3.5" aria-hidden />
          Daily challenge
        </span>
        <h3 className="mt-1 font-display text-xl font-bold leading-tight">{game.title}</h3>
        <p className="text-sm text-muted-foreground">{game.tagline}</p>
      </div>
      {done ? (
        <span className="relative inline-flex items-center gap-1.5 rounded-full bg-lime/15 px-3 py-1.5 text-sm font-semibold text-lime">
          <Check className="size-4" aria-hidden />
          Done
        </span>
      ) : (
        <span
          className={cn(
            'relative inline-flex size-10 items-center justify-center rounded-full transition-transform group-hover:translate-x-1',
            accent.softBg,
            accent.text,
          )}
        >
          <ArrowRight className="size-5" aria-hidden />
        </span>
      )}
    </Link>
  )
}
