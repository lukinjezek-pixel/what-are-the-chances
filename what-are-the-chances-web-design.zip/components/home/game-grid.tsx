import { GameCard } from '@/components/game-card'
import type { Game } from '@/lib/games'

export function GameGrid({
  title,
  caption,
  games,
  id,
}: {
  title: string
  caption?: string
  games: Game[]
  id?: string
}) {
  return (
    <section id={id} className="scroll-mt-20">
      <div className="mb-4">
        <h2 className="font-display text-2xl font-bold tracking-tight">{title}</h2>
        {caption && <p className="text-sm text-muted-foreground">{caption}</p>}
      </div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        {games.map((g) => (
          <GameCard key={g.slug} game={g} />
        ))}
      </div>
    </section>
  )
}
