'use client'

import { useEffect, useState } from 'react'
import { RotateCcw, Share2, Trophy, Check } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ACCENT_CLASSES, type Game } from '@/lib/games'
import { buildShareText, shareResult } from '@/lib/share'
import { playSound } from '@/lib/sound'
import { cn } from '@/lib/utils'

export function ResultCard({
  game,
  scoreValue,
  scoreCaption,
  reaction,
  shareLine,
  isRecord,
  best,
  onTryAgain,
}: {
  game: Game
  /** big headline value, e.g. "312 ms" or "Level 7" */
  scoreValue: string
  /** small caption under the score */
  scoreCaption?: string
  /** fun one-liner reaction to the score */
  reaction: string
  /** the human sentence used in the share text */
  shareLine: string
  isRecord?: boolean
  best?: string | null
  onTryAgain: () => void
}) {
  const accent = ACCENT_CLASSES[game.accent]
  const [shareState, setShareState] = useState<'idle' | 'shared' | 'copied'>('idle')

  // Celebrate the result when the card appears: a fanfare for a new record,
  // otherwise a simple win chime.
  useEffect(() => {
    playSound(isRecord ? 'best' : 'win')
  }, [isRecord])

  async function handleShare() {
    const result = await shareResult({
      title: `${game.title} — What Are the Chances?`,
      text: buildShareText(game.title, shareLine),
    })
    if (result === 'shared') setShareState('shared')
    else if (result === 'copied') {
      setShareState('copied')
      setTimeout(() => setShareState('idle'), 2200)
    }
  }

  return (
    <div className="animate-pop-in mx-auto flex w-full max-w-md flex-col items-center gap-6 text-center">
      <div
        className={cn(
          'flex w-full flex-col items-center gap-2 rounded-3xl border p-8',
          accent.border,
          accent.softBg,
        )}
      >
        {isRecord && (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-gold/15 px-3 py-1 text-xs font-bold uppercase tracking-wide text-gold">
            <Trophy className="size-3.5" aria-hidden />
            New personal best
          </span>
        )}
        <p className="text-sm font-medium uppercase tracking-[0.2em] text-muted-foreground">
          Your result
        </p>
        <p className={cn('font-display text-6xl font-bold leading-none', accent.text)}>
          {scoreValue}
        </p>
        {scoreCaption && (
          <p className="text-sm text-muted-foreground">{scoreCaption}</p>
        )}
      </div>

      <p className="text-balance text-lg font-medium">{reaction}</p>

      {best != null && (
        <p className="text-sm text-muted-foreground">
          Best: <span className="font-semibold text-foreground">{best}</span>
        </p>
      )}

      <div className="flex w-full flex-col gap-3">
        <Button
          size="lg"
          onClick={onTryAgain}
          className="h-14 rounded-2xl text-base font-bold"
        >
          <RotateCcw className="size-5" aria-hidden />
          Try again
        </Button>
        <Button
          size="lg"
          variant="secondary"
          onClick={handleShare}
          className="h-14 rounded-2xl text-base font-bold"
        >
          {shareState === 'copied' ? (
            <>
              <Check className="size-5" aria-hidden />
              Copied — now paste it!
            </>
          ) : (
            <>
              <Share2 className="size-5" aria-hidden />
              Challenge a friend
            </>
          )}
        </Button>
      </div>

      <div className="w-full rounded-2xl border border-border/60 bg-muted/30 p-4 text-left">
        <p className="mb-1 text-[10px] font-semibold uppercase tracking-[0.2em] text-muted-foreground/70">
          Shareable message
        </p>
        <p className="text-sm text-foreground/90">{buildShareText(game.title, shareLine)}</p>
      </div>
    </div>
  )
}
