import {
  Brain,
  Clover,
  Gauge,
  Grid,
  Hash,
  MousePointer,
  Scale,
  Shuffle,
  Timer,
  type LucideIcon,
} from 'lucide-react'

export type ScoreDirection = 'higher' | 'lower'

export type GameSection = 'trending' | 'quick' | 'versus'

export type Game = {
  slug: string
  title: string
  short: string
  tagline: string
  description: string
  icon: LucideIcon
  /** tailwind color token used for accents (lime | pink | cyan | gold | primary) */
  accent: 'lime' | 'pink' | 'cyan' | 'gold' | 'primary'
  sections: GameSection[]
  scoreDirection: ScoreDirection
  scoreUnit: string
  /** SEO */
  metaTitle: string
  metaDescription: string
}

export const GAMES: Game[] = [
  {
    slug: 'reaction',
    title: 'Reaction Test',
    short: 'Reaction',
    tagline: 'Click the instant it turns green.',
    description:
      'Wait for the screen to flash green, then tap as fast as humanly possible. Measure your reaction time in milliseconds and see if you have pro-gamer reflexes.',
    icon: Timer,
    accent: 'lime',
    sections: ['trending', 'quick', 'versus'],
    scoreDirection: 'lower',
    scoreUnit: 'ms',
    metaTitle: 'Reaction Test — How Fast Are Your Reflexes?',
    metaDescription:
      'Test your reaction time in milliseconds. Tap the moment the screen turns green and find out if your reflexes are lightning fast.',
  },
  {
    slug: 'impossible-choice',
    title: 'Impossible Choice',
    short: 'Choice',
    tagline: 'Two options. No good answer.',
    description:
      'Face a stream of impossible would-you-rather dilemmas and pick a side. See how your gut instinct stacks up against everyone else who dared to choose.',
    icon: Scale,
    accent: 'pink',
    sections: ['trending', 'quick'],
    scoreDirection: 'higher',
    scoreUnit: 'picks',
    metaTitle: 'Impossible Choice — Would You Rather Dilemmas',
    metaDescription:
      'Pick a side in a stream of impossible would-you-rather dilemmas and compare your instinct with the crowd.',
  },
  {
    slug: 'number-guess',
    title: 'Number Guess',
    short: 'Guess',
    tagline: 'Find the secret number.',
    description:
      'A secret number between 1 and 100 is hiding. Use higher / lower hints to zero in on it with as few guesses as possible. Pure deduction under pressure.',
    icon: Hash,
    accent: 'cyan',
    sections: ['quick'],
    scoreDirection: 'lower',
    scoreUnit: 'guesses',
    metaTitle: 'Number Guess — Crack the Secret Number',
    metaDescription:
      'Guess the hidden number between 1 and 100 in as few tries as possible using higher and lower hints.',
  },
  {
    slug: 'memory',
    title: 'Memory Test',
    short: 'Memory',
    tagline: 'Repeat the glowing sequence.',
    description:
      'Watch the tiles light up, then repeat the pattern back. Each round adds one more step. How long a sequence can your brain hold before it slips?',
    icon: Grid,
    accent: 'primary',
    sections: ['trending', 'quick', 'versus'],
    scoreDirection: 'higher',
    scoreUnit: 'level',
    metaTitle: 'Memory Test — How Long Is Your Memory Sequence?',
    metaDescription:
      'Watch and repeat a growing sequence of glowing tiles. Push your short-term memory to its limit.',
  },
  {
    slug: 'speed-click',
    title: 'Speed Click',
    short: 'Speed',
    tagline: 'Clicks per 10 seconds.',
    description:
      'You get 10 seconds. Tap, click and mash as many times as you possibly can. A brutal test of finger speed and stamina — great for settling arguments.',
    icon: MousePointer,
    accent: 'gold',
    sections: ['trending', 'versus'],
    scoreDirection: 'higher',
    scoreUnit: 'clicks',
    metaTitle: 'Speed Click — How Many Clicks in 10 Seconds?',
    metaDescription:
      'Click and tap as fast as you can for 10 seconds. Count your clicks and challenge friends to beat your score.',
  },
  {
    slug: 'random-challenge',
    title: 'Random Challenge',
    short: 'Challenge',
    tagline: 'A surprise dare, every time.',
    description:
      'Hit the button and the site throws a random real-world challenge at you — silly, social or physical. Accept it, do it, then dare a friend to try the same.',
    icon: Shuffle,
    accent: 'pink',
    sections: ['trending', 'versus'],
    scoreDirection: 'higher',
    scoreUnit: 'accepted',
    metaTitle: 'Random Challenge Generator — Get a Surprise Dare',
    metaDescription:
      'Generate a random, harmless real-world challenge and dare your friends to complete it too.',
  },
  {
    slug: 'luck',
    title: 'Luck Test',
    short: 'Luck',
    tagline: 'How lucky are you today?',
    description:
      'Play several quick rounds of pure chance — no skill involved. At the end you get a luck rating out of 100. Come back daily to see if fortune favors you.',
    icon: Clover,
    accent: 'lime',
    sections: ['quick', 'versus'],
    scoreDirection: 'higher',
    scoreUnit: '/100',
    metaTitle: 'Luck Test — How Lucky Are You Right Now?',
    metaDescription:
      'Play quick rounds of pure chance and get a luck rating out of 100. No money, no risk — just fun.',
  },
  {
    slug: 'brain',
    title: 'Brain Test',
    short: 'Brain',
    tagline: 'Quick-fire logic questions.',
    description:
      'Answer a rapid set of short logic and trick questions before the clock runs out. Simple to read, sneaky to solve. How many can you get right?',
    icon: Brain,
    accent: 'cyan',
    sections: ['quick', 'versus'],
    scoreDirection: 'higher',
    scoreUnit: 'correct',
    metaTitle: 'Brain Test — Quick Logic & Trick Questions',
    metaDescription:
      'Answer a rapid set of short logic and trick questions and see how sharp your brain really is.',
  },
]

export function getGame(slug: string): Game | undefined {
  return GAMES.find((g) => g.slug === slug)
}

export function gamesInSection(section: GameSection): Game[] {
  return GAMES.filter((g) => g.sections.includes(section))
}

/** Deterministic "game of the day" — same for everyone on a given date. */
export function getDailyGame(date = new Date()): Game {
  const seed = date.getFullYear() * 1000 + date.getMonth() * 40 + date.getDate()
  return GAMES[seed % GAMES.length]
}

export const ACCENT_CLASSES: Record<
  Game['accent'],
  { text: string; bg: string; ring: string; softBg: string; border: string }
> = {
  lime: {
    text: 'text-lime',
    bg: 'bg-lime',
    ring: 'ring-lime/40',
    softBg: 'bg-lime/12',
    border: 'border-lime/30',
  },
  pink: {
    text: 'text-pink',
    bg: 'bg-pink',
    ring: 'ring-pink/40',
    softBg: 'bg-pink/12',
    border: 'border-pink/30',
  },
  cyan: {
    text: 'text-cyan',
    bg: 'bg-cyan',
    ring: 'ring-cyan/40',
    softBg: 'bg-cyan/12',
    border: 'border-cyan/30',
  },
  gold: {
    text: 'text-gold',
    bg: 'bg-gold',
    ring: 'ring-gold/40',
    softBg: 'bg-gold/12',
    border: 'border-gold/30',
  },
  primary: {
    text: 'text-primary',
    bg: 'bg-primary',
    ring: 'ring-primary/40',
    softBg: 'bg-primary/12',
    border: 'border-primary/30',
  },
}
