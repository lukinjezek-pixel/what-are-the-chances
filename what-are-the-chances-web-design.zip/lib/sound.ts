'use client'

/**
 * Tiny synthesized sound engine built on the Web Audio API.
 * No audio assets needed — every effect is generated from oscillators,
 * so there's nothing to download and latency is near-zero.
 */

import { useEffect, useState } from 'react'

const MUTE_KEY = 'watc:muted'
const MUTE_EVENT = 'watc:muted-change'

let ctx: AudioContext | null = null
let muted = false

// Read the persisted preference eagerly on the client.
if (typeof window !== 'undefined') {
  try {
    muted = window.localStorage.getItem(MUTE_KEY) === '1'
  } catch {
    muted = false
  }
}

function getContext(): AudioContext | null {
  if (typeof window === 'undefined') return null
  const AudioCtx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext })
      .webkitAudioContext
  if (!AudioCtx) return null
  if (!ctx) ctx = new AudioCtx()
  // Browsers suspend the context until a user gesture resumes it.
  if (ctx.state === 'suspended') void ctx.resume()
  return ctx
}

type Voice = {
  freq: number
  /** relative start time in seconds */
  at?: number
  dur?: number
  type?: OscillatorType
  gain?: number
  /** glide to this frequency across the note */
  slideTo?: number
}

function playVoices(voices: Voice[]) {
  const audio = getContext()
  if (!audio) return
  const now = audio.currentTime
  for (const v of voices) {
    const osc = audio.createOscillator()
    const amp = audio.createGain()
    const start = now + (v.at ?? 0)
    const dur = v.dur ?? 0.12
    const peak = (v.gain ?? 0.18)

    osc.type = v.type ?? 'sine'
    osc.frequency.setValueAtTime(v.freq, start)
    if (v.slideTo) {
      osc.frequency.exponentialRampToValueAtTime(
        Math.max(1, v.slideTo),
        start + dur,
      )
    }

    // Fast attack, smooth exponential decay to avoid clicks.
    amp.gain.setValueAtTime(0.0001, start)
    amp.gain.exponentialRampToValueAtTime(peak, start + 0.01)
    amp.gain.exponentialRampToValueAtTime(0.0001, start + dur)

    osc.connect(amp).connect(audio.destination)
    osc.start(start)
    osc.stop(start + dur + 0.02)
  }
}

export type SoundName =
  | 'click'
  | 'start'
  | 'correct'
  | 'wrong'
  | 'tick'
  | 'countdown'
  | 'win'
  | 'lose'
  | 'best'
  | 'reveal'

const RECIPES: Record<SoundName, () => Voice[]> = {
  click: () => [{ freq: 420, type: 'triangle', dur: 0.06, gain: 0.12 }],
  start: () => [
    { freq: 440, type: 'triangle', dur: 0.1 },
    { freq: 660, type: 'triangle', at: 0.09, dur: 0.14 },
  ],
  correct: () => [
    { freq: 660, type: 'triangle', dur: 0.1 },
    { freq: 880, type: 'triangle', at: 0.08, dur: 0.16 },
  ],
  wrong: () => [
    { freq: 200, type: 'sawtooth', dur: 0.28, gain: 0.16, slideTo: 90 },
  ],
  tick: () => [{ freq: 900, type: 'square', dur: 0.03, gain: 0.06 }],
  countdown: () => [{ freq: 520, type: 'triangle', dur: 0.12, gain: 0.14 }],
  win: () => [
    { freq: 523, type: 'triangle', dur: 0.14 },
    { freq: 659, type: 'triangle', at: 0.12, dur: 0.14 },
    { freq: 784, type: 'triangle', at: 0.24, dur: 0.14 },
    { freq: 1046, type: 'triangle', at: 0.36, dur: 0.24 },
  ],
  lose: () => [
    { freq: 392, type: 'sawtooth', dur: 0.16, gain: 0.14, slideTo: 300 },
    { freq: 294, type: 'sawtooth', at: 0.16, dur: 0.28, gain: 0.14, slideTo: 180 },
  ],
  best: () => [
    { freq: 523, type: 'triangle', dur: 0.12 },
    { freq: 659, type: 'triangle', at: 0.1, dur: 0.12 },
    { freq: 784, type: 'triangle', at: 0.2, dur: 0.12 },
    { freq: 1046, type: 'triangle', at: 0.3, dur: 0.14 },
    { freq: 1318, type: 'triangle', at: 0.42, dur: 0.3, gain: 0.2 },
  ],
  reveal: () => [{ freq: 760, type: 'sine', dur: 0.1, gain: 0.12, slideTo: 1020 }],
}

/** Play a sound effect by name. No-op when muted or unsupported. */
export function playSound(name: SoundName) {
  if (muted) return
  const recipe = RECIPES[name]
  if (recipe) playVoices(recipe())
}

export function isMuted(): boolean {
  return muted
}

export function setMuted(next: boolean) {
  muted = next
  if (typeof window === 'undefined') return
  try {
    window.localStorage.setItem(MUTE_KEY, next ? '1' : '0')
  } catch {
    /* ignore persistence failures */
  }
  window.dispatchEvent(new CustomEvent(MUTE_EVENT))
}

export function toggleMuted(): boolean {
  setMuted(!muted)
  return muted
}

/** Reactive hook for the mute state, synced across components and tabs. */
export function useMuted(): boolean {
  const [value, setValue] = useState(muted)
  useEffect(() => {
    setValue(muted)
    const sync = () => setValue(muted)
    const onStorage = (e: StorageEvent) => {
      if (e.key === MUTE_KEY) {
        muted = e.newValue === '1'
        setValue(muted)
      }
    }
    window.addEventListener(MUTE_EVENT, sync)
    window.addEventListener('storage', onStorage)
    return () => {
      window.removeEventListener(MUTE_EVENT, sync)
      window.removeEventListener('storage', onStorage)
    }
  }, [])
  return value
}
