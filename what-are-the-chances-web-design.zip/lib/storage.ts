'use client'

import type { ScoreDirection } from './games'

const PREFIX = 'watc:'

function safeGet(key: string): string | null {
  if (typeof window === 'undefined') return null
  try {
    return window.localStorage.getItem(PREFIX + key)
  } catch {
    return null
  }
}

function safeSet(key: string, value: string) {
  if (typeof window === 'undefined') return
  try {
    window.localStorage.setItem(PREFIX + key, value)
  } catch {
    /* storage full or blocked — ignore, scores are non-critical */
  }
}

/* ---------- best scores ---------- */

export function getBest(slug: string): number | null {
  const raw = safeGet(`best:${slug}`)
  if (raw === null) return null
  const n = Number(raw)
  return Number.isFinite(n) ? n : null
}

/**
 * Stores the score if it beats the existing best for the given direction.
 * Returns true when a new record was set.
 */
export function submitScore(
  slug: string,
  score: number,
  direction: ScoreDirection,
): boolean {
  const current = getBest(slug)
  const isBetter =
    current === null ||
    (direction === 'higher' ? score > current : score < current)
  if (isBetter) {
    safeSet(`best:${slug}`, String(score))
    return true
  }
  return false
}

/* ---------- streak ---------- */

export type Streak = { count: number; lastDay: string }

function todayKey(): string {
  return new Date().toISOString().slice(0, 10)
}

function dayDiff(a: string, b: string): number {
  const da = new Date(a + 'T00:00:00')
  const db = new Date(b + 'T00:00:00')
  return Math.round((db.getTime() - da.getTime()) / 86_400_000)
}

export function getStreak(): number {
  const raw = safeGet('streak')
  if (!raw) return 0
  try {
    const s = JSON.parse(raw) as Streak
    const diff = dayDiff(s.lastDay, todayKey())
    // streak stays valid only for today or yesterday
    return diff <= 1 ? s.count : 0
  } catch {
    return 0
  }
}

/** Call once when the user completes any game. Returns the updated streak. */
export function registerPlay(): number {
  const today = todayKey()
  const raw = safeGet('streak')
  let next: Streak
  if (!raw) {
    next = { count: 1, lastDay: today }
  } else {
    try {
      const s = JSON.parse(raw) as Streak
      const diff = dayDiff(s.lastDay, today)
      if (diff === 0) {
        next = s // already counted today
      } else if (diff === 1) {
        next = { count: s.count + 1, lastDay: today }
      } else {
        next = { count: 1, lastDay: today }
      }
    } catch {
      next = { count: 1, lastDay: today }
    }
  }
  safeSet('streak', JSON.stringify(next))
  return next.count
}

/* ---------- daily challenge ---------- */

/** Deterministic index for "today" so everyone gets the same daily game. */
export function dailyIndex(total: number): number {
  const d = new Date()
  const seed = d.getFullYear() * 1000 + d.getMonth() * 40 + d.getDate()
  return seed % total
}

export function isDailyDone(slug: string): boolean {
  return safeGet(`daily:${todayKey()}`) === slug
}

export function markDailyDone(slug: string) {
  safeSet(`daily:${todayKey()}`, slug)
}
