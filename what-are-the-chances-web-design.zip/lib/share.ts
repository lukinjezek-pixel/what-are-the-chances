'use client'

const SITE = 'What Are the Chances?'

/**
 * Tries the native share sheet first (great on mobile), then falls back to
 * copying the text + link to the clipboard. Returns how it was shared.
 */
export async function shareResult(opts: {
  title: string
  text: string
  url?: string
}): Promise<'shared' | 'copied' | 'failed'> {
  const url =
    opts.url ?? (typeof window !== 'undefined' ? window.location.href : '')
  const nav = typeof navigator !== 'undefined' ? navigator : undefined

  if (nav && typeof nav.share === 'function') {
    try {
      await nav.share({ title: opts.title, text: opts.text, url })
      return 'shared'
    } catch (err) {
      // User cancelled the native sheet — treat as a no-op, not an error.
      if (err instanceof DOMException && err.name === 'AbortError') {
        return 'failed'
      }
    }
  }

  if (nav?.clipboard && typeof nav.clipboard.writeText === 'function') {
    try {
      await nav.clipboard.writeText(`${opts.text}\n${url}`)
      return 'copied'
    } catch {
      return 'failed'
    }
  }
  return 'failed'
}

export function buildShareText(gameTitle: string, line: string): string {
  return `${line} — beat me on ${SITE}: ${gameTitle}`
}
